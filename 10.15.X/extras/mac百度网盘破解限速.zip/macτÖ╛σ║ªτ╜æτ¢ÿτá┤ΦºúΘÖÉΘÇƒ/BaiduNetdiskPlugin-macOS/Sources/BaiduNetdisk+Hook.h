#import <Foundation/Foundation.h>

@interface NSObject (BaiduNetdisk)

+ (void)hookBaiduNetdisk;

@end
